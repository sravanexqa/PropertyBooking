import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import{emailValidator} from '../signup/email-validator.directive';

interface SUser {
  email: string;
  password: string;
  rpassword: string;
  showPassword: boolean;
}
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {
  signForm!: FormGroup;
    signinuser: SUser;

  constructor() { 
    this.signinuser = {} as SUser;
  }

  ngOnInit(): void {
    this.signForm = new FormGroup({
      email: new FormControl(this.signinuser.email, [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(50),
          emailValidator(),
      ]),
      password: new FormControl(this.signinuser.password, [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(15),
      ]),
      rpassword: new FormControl(this.signinuser.rpassword, [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(15),
      ]),
      

  },
  // { validators: this.Mustmatch('password', 'confirmPassword') }
  )
  }
  get email() {
    return this.signForm.get('email')!;
  }
  
  get password() {
    return this.signForm.get('password')!;
  }
  get rpassword() {
    return this.signForm.get('rpassword')!;
  }
  public validate(): void {
    if (this.signForm.invalid) {
        for (const control of Object.keys(this.signForm.controls)) {
            this.signForm.controls[control].markAsTouched();
        }
        return;
    }

    this.signinuser = this.signForm.value;
    console.info('Email:', this.signinuser.email);
    console.info('Password:', this.signinuser.password);
    console.info('RPassword:', this.signinuser.rpassword);
}
}


