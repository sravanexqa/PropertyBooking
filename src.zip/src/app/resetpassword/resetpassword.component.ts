import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { emailValidator } from '../signup/email-validator.directive';

interface Rpwd {
  email: string;
}

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.scss']
})
export class ResetpasswordComponent implements OnInit {
  rpwdForm!: FormGroup;
  resetpwd: Rpwd;
  constructor() {
    this.resetpwd = {} as Rpwd;
  }

  ngOnInit(): void {
    this.rpwdForm = new FormGroup({
      email: new FormControl(this.resetpwd.email, [
        Validators.required,
        Validators.minLength(1),
        Validators.maxLength(50),
        emailValidator(),
      ]),
    },
    )
  }
  get email() {
    return this.rpwdForm.get('email')!;
  }
  public validate(): void {
    if (this.rpwdForm.invalid) {
        for (const control of Object.keys(this.rpwdForm.controls)) {
            this.rpwdForm.controls[control].markAsTouched();
        }
        return;
    }

    this.resetpwd = this.rpwdForm.value;
    console.info('Email:', this.resetpwd.email);
}
}
